import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;

public class AlgoritmoBanquero extends JFrame {

    private final int procesos = 5;
    private final int recursos = 3;

    private int[] disponibles = {3, 3, 2};

    private int[][] asignado = {
            {0, 1, 0},
            {2, 0, 0},
            {3, 0, 2},
            {2, 1, 1},
            {0, 0, 2}
    };

    private int[][] maximo = {
            {7, 5, 3},
            {3, 2, 2},
            {9, 0, 2},
            {2, 2, 2},
            {4, 3, 3}
    };

    private JTable tablaAsignado;
    private JTable tablaMaximo;
    private JTable tablaNecesidad;
    private JTextField txtDisponibles;
    private JTextArea resultado;

    public AlgoritmoBanquero() {
        setTitle("Simulador del Algoritmo del Banquero");
        setSize(950, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel titulo = new JLabel("ALGORITMO DEL BANQUERO", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(new Color(20, 70, 140));
        add(titulo, BorderLayout.NORTH);

        tablaAsignado = crearTabla();
        tablaMaximo = crearTabla();
        tablaNecesidad = crearTabla();

        JPanel panelMatrices = new JPanel(new GridLayout(1, 3, 10, 10));
        panelMatrices.add(crearPanel("Asignación", tablaAsignado));
        panelMatrices.add(crearPanel("Máximo", tablaMaximo));
        panelMatrices.add(crearPanel("Necesidad", tablaNecesidad));

        JPanel controles = new JPanel(new FlowLayout());
        controles.add(new JLabel("Disponibles A,B,C:"));
        txtDisponibles = new JTextField("3,3,2", 12);
        controles.add(txtDisponibles);

        JButton btnCalcular = new JButton("Calcular necesidad");
        JButton btnEjecutar = new JButton("Ejecutar algoritmo");
        JButton btnReiniciar = new JButton("Restablecer");

        controles.add(btnCalcular);
        controles.add(btnEjecutar);
        controles.add(btnReiniciar);

        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.add(panelMatrices, BorderLayout.CENTER);
        centro.add(controles, BorderLayout.SOUTH);

        add(centro, BorderLayout.CENTER);

        resultado = new JTextArea(12, 60);
        resultado.setEditable(false);
        resultado.setFont(new Font("Monospaced", Font.PLAIN, 14));
        resultado.setBackground(new Color(240, 245, 250));

        JPanel panelResultado = new JPanel(new BorderLayout());
        panelResultado.setBorder(BorderFactory.createTitledBorder("Resultado de la simulación"));
        panelResultado.add(new JScrollPane(resultado));
        panelResultado.setPreferredSize(new Dimension(900, 260));

        add(panelResultado, BorderLayout.SOUTH);

        cargarDatos();
        calcularNecesidad();

        btnCalcular.addActionListener(e -> {
            try {
                leerDatos();
                calcularNecesidad();
                resultado.setText("Necesidades calculadas correctamente.");
            } catch (Exception ex) {
                mostrarError(ex.getMessage());
            }
        });

        btnEjecutar.addActionListener(e -> {
            try {
                leerDatos();
                calcularNecesidad();
                ejecutarBanquero();
            } catch (Exception ex) {
                mostrarError(ex.getMessage());
            }
        });

        btnReiniciar.addActionListener(e -> {
            disponibles = new int[]{3, 3, 2};

            asignado = new int[][]{
                    {0, 1, 0},
                    {2, 0, 0},
                    {3, 0, 2},
                    {2, 1, 1},
                    {0, 0, 2}
            };

            maximo = new int[][]{
                    {7, 5, 3},
                    {3, 2, 2},
                    {9, 0, 2},
                    {2, 2, 2},
                    {4, 3, 3}
            };

            txtDisponibles.setText("3,3,2");
            cargarDatos();
            calcularNecesidad();
            resultado.setText("Valores iniciales restaurados.");
        });
    }

    private JTable crearTabla() {
        String[] columnas = {"Proceso", "A", "B", "C"};

        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return columna != 0;
            }
        };

        for (int i = 0; i < procesos; i++) {
            modelo.addRow(new Object[]{"P" + i, 0, 0, 0});
        }

        JTable tabla = new JTable(modelo);
        tabla.setRowHeight(35);
        tabla.setFont(new Font("Arial", Font.PLAIN, 14));
        tabla.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        return tabla;
    }

    private JPanel crearPanel(String nombre, JTable tabla) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(nombre));
        panel.add(new JScrollPane(tabla), BorderLayout.CENTER);
        return panel;
    }

    private void cargarDatos() {
        for (int i = 0; i < procesos; i++) {
            for (int j = 0; j < recursos; j++) {
                tablaAsignado.setValueAt(asignado[i][j], i, j + 1);
                tablaMaximo.setValueAt(maximo[i][j], i, j + 1);
            }
        }
    }

    private void leerDatos() {
        if (tablaAsignado.isEditing()) {
            tablaAsignado.getCellEditor().stopCellEditing();
        }
        if (tablaMaximo.isEditing()) {
            tablaMaximo.getCellEditor().stopCellEditing();
        }

        String[] valores = txtDisponibles.getText().split(",");
        if (valores.length != recursos) {
            throw new RuntimeException("Escribe los disponibles así: 3,3,2");
        }

        int[] nuevosDisponibles = new int[recursos];
        int[][] nuevosAsignados = new int[procesos][recursos];
        int[][] nuevosMaximos = new int[procesos][recursos];

        for (int j = 0; j < recursos; j++) {
            nuevosDisponibles[j] = Integer.parseInt(valores[j].trim());
            if (nuevosDisponibles[j] < 0) {
                throw new RuntimeException("Los disponibles no pueden ser negativos.");
            }
        }

        for (int i = 0; i < procesos; i++) {
            for (int j = 0; j < recursos; j++) {
                int a = Integer.parseInt(tablaAsignado.getValueAt(i, j + 1).toString());
                int m = Integer.parseInt(tablaMaximo.getValueAt(i, j + 1).toString());

                if (a < 0 || m < 0) {
                    throw new RuntimeException("No se permiten valores negativos.");
                }

                if (a > m) {
                    throw new RuntimeException("En P" + i + ", asignado no puede ser mayor que máximo.");
                }

                nuevosAsignados[i][j] = a;
                nuevosMaximos[i][j] = m;
            }
        }

        disponibles = nuevosDisponibles;
        asignado = nuevosAsignados;
        maximo = nuevosMaximos;
    }

    private int[][] calcularNecesidad() {
        int[][] necesidad = new int[procesos][recursos];

        for (int i = 0; i < procesos; i++) {
            for (int j = 0; j < recursos; j++) {
                necesidad[i][j] = maximo[i][j] - asignado[i][j];
                tablaNecesidad.setValueAt(necesidad[i][j], i, j + 1);
            }
        }

        tablaNecesidad.setEnabled(false);
        return necesidad;
    }

    private void ejecutarBanquero() {
        int[][] necesidad = calcularNecesidad();
        int[] trabajo = disponibles.clone();
        boolean[] terminado = new boolean[procesos];
        List<Integer> secuencia = new ArrayList<>();

        StringBuilder texto = new StringBuilder();
        texto.append("SIMULACIÓN DEL ALGORITMO DEL BANQUERO\n");
        texto.append("----------------------------------------\n");
        texto.append("Recursos disponibles: ");
        for (int i = 0; i < trabajo.length; i++) {
            texto.append(trabajo[i]);
            if (i < trabajo.length - 1) texto.append(", ");
        }
        texto.append("\n\n");

        boolean avance;

        do {
            avance = false;

            for (int i = 0; i < procesos; i++) {
                if (!terminado[i]) {
                    boolean puedeEjecutar = true;

                    for (int j = 0; j < recursos; j++) {
                        if (necesidad[i][j] > trabajo[j]) {
                            puedeEjecutar = false;
                            break;
                        }
                    }

                    if (puedeEjecutar) {
                        texto.append("Proceso P").append(i).append(" puede ejecutarse.\n");

                        for (int j = 0; j < recursos; j++) {
                            trabajo[j] += asignado[i][j];
                        }

                        terminado[i] = true;
                        secuencia.add(i);
                        avance = true;

                        texto.append("Libera recursos. Disponibles: ");
                        for (int j = 0; j < trabajo.length; j++) {
                            texto.append(trabajo[j]);
                            if (j < trabajo.length - 1) texto.append(", ");
                        }
                        texto.append("\n\n");
                    }
                }
            }
        } while (avance);

        boolean seguro = true;
        for (boolean t : terminado) {
            if (!t) {
                seguro = false;
                break;
            }
        }

        if (seguro) {
            texto.append("RESULTADO: SISTEMA SEGURO\n\n");
            texto.append("Secuencia segura: ");
            for (int i = 0; i < secuencia.size(); i++) {
                texto.append("P").append(secuencia.get(i));
                if (i < secuencia.size() - 1) texto.append(" -> ");
            }
            texto.append("\n\nTodos los procesos pueden finalizar.");
            resultado.setForeground(new Color(0, 120, 40));
        } else {
            texto.append("RESULTADO: ESTADO INSEGURO\n\n");
            texto.append("Procesos sin completar: ");
            boolean primero = true;
            for (int i = 0; i < procesos; i++) {
                if (!terminado[i]) {
                    if (!primero) texto.append(", ");
                    texto.append("P").append(i);
                    primero = false;
                }
            }
            texto.append("\n\nNo se encontró una secuencia segura.");
            resultado.setForeground(new Color(190, 40, 40));
        }

        resultado.setText(texto.toString());
        resultado.setCaretPosition(0);
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AlgoritmoBanquero().setVisible(true);
        });
    }
}